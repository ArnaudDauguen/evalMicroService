package com.jsonplaceholder.usertodos.entities;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
public class UserTodosDTO { //DTO: Data Transfer Object
    private User user;
    private List<Todo> todo;

}
