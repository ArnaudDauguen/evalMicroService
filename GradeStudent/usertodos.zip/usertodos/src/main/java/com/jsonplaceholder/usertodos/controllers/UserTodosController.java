package com.jsonplaceholder.usertodos.controllers;

import com.jsonplaceholder.usertodos.entities.UserTodosDTO;
import com.jsonplaceholder.usertodos.services.UserTodosService;
import feign.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserTodosController {

    @Autowired
    UserTodosService userTodosService;

    @RequestMapping("/userTodos/{userId}")
    ResponseEntity<UserTodosDTO> getUserTodos(@Param("userId") Integer userId){
        return new ResponseEntity<>(userTodosService.getUserTodos(userId), HttpStatus.OK);
    }

}
