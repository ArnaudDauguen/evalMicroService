package com.jsonplaceholder.usertodos.clients;

import com.jsonplaceholder.usertodos.entities.Todo;
import feign.RequestLine;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@FeignClient(name= "TodoClient")
public interface ITodoClient {

    @RequestLine("GET /")
    List<Todo> getAll();
}
