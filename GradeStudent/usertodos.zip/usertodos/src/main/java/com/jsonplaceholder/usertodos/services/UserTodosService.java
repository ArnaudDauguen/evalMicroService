package com.jsonplaceholder.usertodos.services;

import com.jsonplaceholder.usertodos.clients.ITodoClient;
import com.jsonplaceholder.usertodos.clients.IUserClient;
import com.jsonplaceholder.usertodos.entities.Todo;
import com.jsonplaceholder.usertodos.entities.User;
import com.jsonplaceholder.usertodos.entities.UserTodosDTO;
import feign.Feign;
import feign.Logger;
import feign.gson.GsonDecoder;
import feign.gson.GsonEncoder;
import feign.okhttp.OkHttpClient;
import feign.slf4j.Slf4jLogger;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
@Data
public class UserTodosService {

    private ITodoClient iTodoClient = Feign.builder()
            .client(new OkHttpClient())
            .encoder(new GsonEncoder())
            .decoder(new GsonDecoder())
            .logger(new Slf4jLogger(String.class))
            .logLevel(Logger.Level.FULL)
            .target(ITodoClient.class, "https://jsonplaceholder.typicode.com/todos");

    private IUserClient iUserClient = Feign.builder()
            .client(new OkHttpClient())
            .encoder(new GsonEncoder())
            .decoder(new GsonDecoder())
            .logger(new Slf4jLogger(String.class))
            .logLevel(Logger.Level.FULL)
            .target(IUserClient.class, "https://jsonplaceholder.typicode.com/users");

    public UserTodosDTO getUserTodos(Integer userId){
        log.info("Call to the user client - getOneById : " + userId);

        User user = iUserClient.getOneById(userId);

        log.info("Call to the todos client - getAll");
        List<Todo> userTodos = iTodoClient.getAll().stream()
                .filter(s -> s.getUserId().equals(userId)).collect(Collectors.toList());

        return new UserTodosDTO(user, userTodos);

    }
}
