package com.jsonplaceholder.usertodos.clients;

import com.jsonplaceholder.usertodos.entities.User;
import feign.Param;
import feign.RequestLine;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;

@Component
@FeignClient(name="UserClient")
public interface IUserClient {

    @RequestLine("GET /{id}")
    User getOneById(@Param("id") Integer id);

}
