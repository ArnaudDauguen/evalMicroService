package com.jsonplaceholder.usertodos.entities;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Todo {

    private Integer id;
    private Integer userId;
    private String title;
    private Boolean completed;
}
